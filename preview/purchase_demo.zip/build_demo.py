"""demo_template.html + demo_model.json + mock_customers.csv → demo.html (파일 하나, 인터넷 없이 열림)

    python build_demo.py
    python build_demo.py --model demo_model.json --mock mock_customers.csv --out demo.html
"""
import argparse
import csv
import json
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--template", default="demo_template.html")
ap.add_argument("--model", default="demo_model.json")
ap.add_argument("--mock", default="mock_customers.csv")
ap.add_argument("--out", default="demo.html")
a = ap.parse_args()

model = json.loads(Path(a.model).read_text(encoding="utf-8"))
with open(a.mock, encoding="utf-8-sig") as f:
    mock = list(csv.DictReader(f))
data = f"const MODEL = {json.dumps(model, ensure_ascii=False)};\nconst MOCK = {json.dumps(mock, ensure_ascii=False)};"
html = Path(a.template).read_text(encoding="utf-8").replace("/*__DATA__*/", data)

# 제목 폰트(Black Han Sans, OFL)를 HTML 안에 넣어서 인터넷 없이도 PPT와 같은 굵은 제목이 나오게 함
font = Path(__file__).with_name("fonts") / "BlackHanSans-subset.woff"
if font.exists():
    import base64
    b64 = base64.b64encode(font.read_bytes()).decode()
    face = ('@font-face { font-family:"Black Han Sans"; font-display:block; '
            f'src:url(data:font/woff;base64,{b64}) format("woff"); }}')
    html = html.replace("/*__FONT__*/", face)
Path(a.out).write_text(html, encoding="utf-8")
print(f"저장: {a.out} (모델 {model.get('name')}, 목업 {len(mock)}행)")
