"""
시연용 목업 데이터 생성: 가상 고객 10명, 고객당 방문 2~4회 (총 30행).

- 컬럼: UCI Online Shoppers 원본과 같은 17개 입력 컬럼 + customer_id, customer_name, visit_no, visit_date
- customer_id / customer_name / visit_no / visit_date 는 화면 표시·고객 묶음용이고 모델 입력에는 안 들어감
- Revenue(정답)는 없음 → 시연에서는 모델이 예측만 함
- 시나리오 이름은 CSV에 넣지 않음 (화면에 정답이 미리 보이지 않게). 아래 주석으로만 관리

시나리오를 만들 때 주로 움직인 컬럼 (EDA에서 구매와 관련이 컸던 것들)
- PageValues : 구매 직전 페이지를 거쳐 간 정도. 클수록 구매 확률 ↑ (영향 가장 큼)
- ExitRates / BounceRates : 클수록 ↓
- ProductRelated(_Duration) : 상품 페이지를 많이/오래 볼수록 대체로 ↑
값은 가상으로 만든 것이고, 확률은 공식 모델(MLP_final_seed42)이 계산한 결과.
모델이 바뀌면 시나리오대로 안 나올 수 있으니 build 후 화면에서 확인할 것.
"""
import csv

COLUMNS = [
    "Administrative", "Administrative_Duration", "Informational", "Informational_Duration",
    "ProductRelated", "ProductRelated_Duration", "BounceRates", "ExitRates", "PageValues",
    "SpecialDay", "Month", "OperatingSystems", "Browser", "Region", "TrafficType",
    "VisitorType", "Weekend",
]
META = ["customer_id", "customer_name", "visit_no", "visit_date"]


def visit(adm, adm_d, inf, inf_d, pr, pr_d, br, er, pv, month, weekend=False,
          special=0.0, os_=2, browser=2, region=1, traffic=2, vtype="Returning_Visitor"):
    return dict(zip(COLUMNS, [adm, adm_d, inf, inf_d, pr, pr_d, br, er, pv, special,
                              month, os_, browser, region, traffic, vtype, weekend]))


CUSTOMERS = [
    # ── 관심 상승 → 구매 임박 ──────────────────────────────
    ("C001", "김민수", [
        ("2026-11-02", visit(1, 20, 0, 0, 12, 380, 0.02, 0.05, 0.0, "Nov", vtype="New_Visitor", traffic=1)),
        ("2026-11-05", visit(3, 75, 0, 0, 28, 1150, 0.01, 0.025, 9.0, "Nov")),
        ("2026-11-08", visit(4, 110, 1, 30, 42, 1900, 0.005, 0.015, 32.0, "Nov", weekend=True)),
    ]),
    ("C006", "강도윤", [
        ("2026-10-28", visit(0, 0, 0, 0, 10, 300, 0.03, 0.06, 0.0, "Oct", region=3)),
        ("2026-11-01", visit(2, 40, 0, 0, 18, 700, 0.02, 0.04, 3.0, "Nov", region=3)),
        ("2026-11-04", visit(3, 80, 0, 0, 30, 1300, 0.01, 0.022, 14.0, "Nov", region=3)),
        ("2026-11-07", visit(6, 180, 1, 40, 60, 2900, 0.002, 0.009, 70.0, "Nov", region=3)),
    ]),
    # ── 꾸준히 높음 → 할인 없이 추천 ──────────────────────
    ("C002", "이서연", [
        ("2026-10-20", visit(3, 90, 1, 15, 35, 1500, 0.004, 0.015, 38.0, "Oct")),
        ("2026-11-01", visit(2, 60, 0, 0, 30, 1300, 0.006, 0.018, 30.0, "Nov", weekend=True)),
        ("2026-11-07", visit(4, 120, 0, 0, 40, 1750, 0.003, 0.012, 42.0, "Nov")),
    ]),
    ("C007", "윤서아", [
        ("2026-11-03", visit(5, 150, 2, 60, 55, 2600, 0.002, 0.01, 55.0, "Nov", os_=3, browser=4)),
        ("2026-11-06", visit(4, 120, 1, 20, 50, 2300, 0.003, 0.011, 48.0, "Nov", os_=3, browser=4, weekend=True)),
    ]),
    # ── 망설임 → 쿠폰 ─────────────────────────────────────
    ("C003", "박지훈", [
        ("2026-11-01", visit(2, 50, 0, 0, 30, 1200, 0.01, 0.03, 4.0, "Nov")),
        ("2026-11-04", visit(2, 45, 1, 20, 34, 1400, 0.01, 0.028, 4.2, "Nov")),
        ("2026-11-07", visit(3, 70, 0, 0, 31, 1250, 0.012, 0.03, 4.5, "Nov")),
    ]),
    ("C008", "장현우", [
        ("2026-10-30", visit(1, 30, 0, 0, 22, 900, 0.015, 0.035, 2.5, "Oct", traffic=4)),
        ("2026-11-03", visit(2, 55, 0, 0, 26, 1100, 0.012, 0.032, 3.0, "Nov", traffic=4)),
        ("2026-11-06", visit(2, 40, 0, 0, 24, 1000, 0.014, 0.034, 3.5, "Nov", traffic=4, weekend=True)),
    ]),
    # ── 관심 하락 → 이탈 방지 쿠폰 ────────────────────────
    ("C004", "최유나", [
        ("2026-10-25", visit(4, 100, 0, 0, 38, 1600, 0.004, 0.014, 35.0, "Oct")),
        ("2026-11-02", visit(2, 40, 0, 0, 20, 700, 0.015, 0.035, 6.0, "Nov")),
        ("2026-11-06", visit(0, 0, 0, 0, 8, 150, 0.05, 0.08, 0.0, "Nov")),
    ]),
    ("C009", "임채원", [
        ("2026-10-22", visit(3, 80, 1, 25, 44, 2000, 0.003, 0.013, 40.0, "Oct", region=2)),
        ("2026-10-29", visit(3, 70, 0, 0, 36, 1500, 0.006, 0.02, 20.0, "Oct", region=2)),
        ("2026-11-03", visit(1, 20, 0, 0, 15, 450, 0.02, 0.045, 2.0, "Nov", region=2)),
        ("2026-11-07", visit(0, 0, 0, 0, 6, 100, 0.06, 0.09, 0.0, "Nov", region=2, weekend=True)),
    ]),
    # ── 둘러보기만 → 광고 줄이기 ──────────────────────────
    ("C005", "정하늘", [
        ("2026-11-03", visit(0, 0, 0, 0, 2, 25, 0.10, 0.15, 0.0, "Nov", vtype="New_Visitor", traffic=3)),
        ("2026-11-05", visit(0, 0, 0, 0, 4, 60, 0.07, 0.11, 0.0, "Nov", traffic=3)),
        ("2026-11-08", visit(0, 0, 0, 0, 2, 20, 0.12, 0.16, 0.0, "Nov", weekend=True, traffic=3)),
    ]),
    ("C010", "한지민", [
        ("2026-11-02", visit(0, 0, 0, 0, 1, 0, 0.2, 0.2, 0.0, "Nov", traffic=13)),
        ("2026-11-06", visit(1, 10, 0, 0, 3, 35, 0.10, 0.15, 0.0, "Nov", traffic=13)),
    ]),
]


def main(out="mock_customers.csv"):
    rows = []
    for cid, name, visits in sorted(CUSTOMERS, key=lambda c: c[0]):
        for i, (date, v) in enumerate(visits, 1):
            rows.append({"customer_id": cid, "customer_name": name, "visit_no": i, "visit_date": date, **v})
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=META + COLUMNS)
        w.writeheader()
        w.writerows(rows)
    print(f"저장: {out} (고객 {len(CUSTOMERS)}명, {len(rows)}행)")


if __name__ == "__main__":
    main()
