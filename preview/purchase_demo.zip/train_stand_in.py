"""
시연 화면을 미리 맞춰보기 위한 '임시' 모델. (발표에는 쓰지 않음)

새 최종 설정을 그대로 따름:
  56-112-56, ReLU + he_normal, 드롭아웃 0.2(모든 은닉층), Adam 학습률 0.01/3,
  배치 64, 최대 30에폭(검증 PR-AUC 최고 에폭 가중치), class_weight balanced, 시드 42
다만 팀 공식 분할 파일(data/final/)이 여기 없어서 원본에서 중복 제거 후 층화 분할(seed 42)을 직접 함
→ 수치가 공식 결과(0.7018)와 조금 다를 수 있음.

결과는 final_model/ 과 같은 형식(mlp_final.keras, scaler.joblib, feature_columns.json)으로 저장해서
export_model.py가 공식 모델과 똑같은 경로로 처리되는지도 같이 확인함.
"""
import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, f1_score, precision_recall_curve
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight

SEED = 42
src = sys.argv[1] if len(sys.argv) > 1 else "data/shoppers.csv"
out_dir = Path("stand_in_model")
out_dir.mkdir(exist_ok=True)

import tensorflow as tf
tf.keras.utils.set_random_seed(SEED)

df = pd.read_csv(src).drop_duplicates().reset_index(drop=True)
y = df["Revenue"].astype(int).values
tr_val, test = train_test_split(df, test_size=0.2, stratify=y, random_state=SEED)
train, val = train_test_split(tr_val, test_size=1221, stratify=tr_val["Revenue"], random_state=SEED)
val.to_csv(out_dir / "val_raw.csv", index=False)  # export 검증용


def feats(d):
    X = d.drop(columns=["Revenue"]).copy()
    X["Weekend"] = X["Weekend"].astype(int)
    return pd.get_dummies(X, columns=["Month", "VisitorType"], drop_first=True, dtype=float)


Xtr = feats(train)
cols = list(Xtr.columns)
Xva = feats(val).reindex(columns=cols, fill_value=0.0)
scaler = StandardScaler().fit(Xtr.values)
Xtr_s, Xva_s = scaler.transform(Xtr.values), scaler.transform(Xva.values)
ytr, yva = train["Revenue"].astype(int).values, val["Revenue"].astype(int).values

cw = compute_class_weight("balanced", classes=np.array([0, 1]), y=ytr)
init = tf.keras.initializers.HeNormal(seed=SEED)
model = tf.keras.Sequential([tf.keras.Input((len(cols),))])
for n in (56, 112, 56):
    model.add(tf.keras.layers.Dense(n, activation="relu", kernel_initializer=init))
    model.add(tf.keras.layers.Dropout(0.2, seed=SEED))
model.add(tf.keras.layers.Dense(1, activation="sigmoid"))
model.compile(optimizer=tf.keras.optimizers.Adam(0.01 / 3), loss="binary_crossentropy")

best, best_w, best_ep = -1, None, 0
for ep in range(1, 31):
    model.fit(Xtr_s, ytr, batch_size=64, epochs=1, verbose=0, class_weight={0: cw[0], 1: cw[1]})
    p = model.predict(Xva_s, verbose=0).ravel()
    ap = average_precision_score(yva, p)
    if ap > best:
        best, best_w, best_ep = ap, model.get_weights(), ep
model.set_weights(best_w)
p = model.predict(Xva_s, verbose=0).ravel()
pr, rc, th = precision_recall_curve(yva, p)
f1 = 2 * pr * rc / (pr + rc + 1e-12)
i = int(np.nanargmax(f1[:-1]))
print(f"검증 PR-AUC {best:.4f} (최고 에폭 {best_ep}) | F1 최대 임계값 {th[i]:.3f}, F1 {f1[i]:.3f}")

model.save(out_dir / "mlp_final.keras")
joblib.dump(scaler, out_dir / "scaler.joblib")
(out_dir / "feature_columns.json").write_text(json.dumps(cols), encoding="utf-8")
(out_dir / "model_card.json").write_text(json.dumps({
    "model_name": "임시 모델", "val_pr_auc": round(best, 4),
    "threshold": round(float(th[i]), 3), "note": "공식 모델 아님"}, ensure_ascii=False), encoding="utf-8")
