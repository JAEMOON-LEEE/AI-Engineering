# 구매 의도 예측 시연 (공식 최종 모델, 2026-11-08)

`demo.html`을 더블클릭하면 인터넷·파이썬 없이 바로 열림.
시연 순서: 빈 화면 → `mock_customers.csv`를 끌어다 놓기(또는 파일 선택) → 예측 → 고객별 추천.
화면의 "예시 데이터로 실행"은 CSV 없이 같은 목업(고객 10명, 방문 30건)을 바로 넣는 백업 버튼.

## 지금 들어 있는 모델 = 공식 동결 모델
`members/C1/final_model/` 의 `MLP_final_seed42` (56-112-56, 2026-11-05 동결), 임계값 **0.75** (B가 검증 세트 F1 최대로 테스트 전에 확정).
공식 validation_final로 다시 계산한 AP 0.7018 = model_card 값과 일치, 화면 계산과 Keras 차이 최대 5e-7.
출력값은 클래스 가중치 때문에 실제 구매 비율보다 높게 나오므로 순위·구간용 점수로 해석.

## 공식 모델로 바꾸기 (팀 저장소 루트에서)
```bash
python export_model.py --model-dir members/C1/final_model --threshold <B가 정한 값> --check-csv data/final/validation_final.csv
python build_demo.py
```
- `final_model/`의 `scaler.joblib`, `feature_columns.json`을 그대로 읽음 (다시 fit 안 함)
- `--threshold`를 안 주면 화면에 "임계값 미확정" 배지가 뜸. 예전 0.66은 예전 모델 기준이라 쓰지 말 것
- `--check-csv`를 주면 화면 아래에 "Keras 예측과 화면 계산의 최대 차이"가 표시됨 (1e-4보다 작으면 초록)
- 화면의 **모델 JSON 교체** 버튼으로 새 `demo_model.json`을 바로 불러와도 됨
- 교체 후 목업 고객 확률이 시나리오와 안 맞으면 `make_mock.py`의 PageValues·ExitRates를 조정 → `python make_mock.py && python build_demo.py`

## 파일
| 파일 | 역할 |
|---|---|
| demo.html | 시연 페이지 (모델·목업 내장) |
| demo_template.html / build_demo.py | 페이지 원본 / 모델·목업을 넣어 demo.html 생성 |
| export_model.py | final_model/ → demo_model.json |
| demo_model.json | 지금 들어 있는 공식 모델 (MLP_final_seed42, 임계값 0.75) |
| make_mock.py / mock_customers.csv | 목업 데이터 (UCI 17개 입력 컬럼 + customer_id 등 표시용 컬럼) |
| fonts/ | 제목 폰트 Black Han Sans (OFL, 한글 2,350자 subset) — build_demo.py가 demo.html 안에 넣음 |
| train_stand_in.py | (참고) 저장소 없이 화면 미리보기용 임시 모델 학습 스크립트 |

## 계산 방식
- 모델: 세션 1건마다 Month·VisitorType 원핫(drop_first=False) → 학습 열 목록으로 reindex(없는 열 0) → 학습 scaler로 표준화 → Dense 층 계산
- 서비스 규칙(모델 밖): 최근 방문 확률이 임계값 이상/0.30~임계값/0.30 미만, 추세(마지막−첫 방문) ±0.15로 고객별 추천 결정. 데이터로 검증한 값 아님

## 목업 결과 (공식 모델, 기준 0.75)
| 고객 | 방문별 확률 | 분류 |
|---|---|---|
| C001 김민수 | 0.47 → 0.79 → 0.85 | 구매 임박 |
| C006 강도윤 | 0.18 → 0.48 → 0.80 → 0.81 | 구매 임박 |
| C002 이서연 | 0.93 → 0.86 → 0.81 | 구매 유력 |
| C007 윤서아 | 0.76 → 0.85 | 구매 유력 |
| C003 박지훈 | 0.69 → 0.72 → 0.70 | 망설임 |
| C008 장현우 | 0.66 → 0.63 → 0.72 | 망설임 |
| C004 최유나 | 0.89 → 0.71 → 0.39 | 이탈 위험 |
| C009 임채원 | 0.93 → 0.91 → 0.42 → 0.44 | 이탈 위험 |
| C005 정하늘 | 0.31 → 0.38 → 0.20 | 관심 낮음 |
| C010 한지민 | 0.20 → 0.29 | 관심 낮음 |
