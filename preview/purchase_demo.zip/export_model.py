"""
최종 Keras 모델을 시연 HTML이 읽을 수 있는 JSON 하나로 내보내기.

사용 (팀 저장소 루트에서):
    python export_model.py --model-dir members/C1/final_model --threshold 0.xx

읽는 파일 (members/C1/final_model/)
- mlp_final.keras        : 동결된 최종 모델 (시드 42)
- scaler.joblib          : 학습 데이터로 fit한 StandardScaler  ← 다시 fit하지 않고 그대로 사용
- feature_columns.json   : 학습 때 입력 열 순서 (26개)
- model_card.json        : 있으면 이름·임계값 참고

왜 JSON으로 내보내나?
  Keras 모델은 파이썬이 있어야 돌아가지만, 예측 계산 자체는
  "입력 × 가중치 + 편향 → 활성화함수" 를 층마다 반복하는 것뿐이라
  가중치만 꺼내 두면 브라우저(JS)에서 똑같이 계산할 수 있음 → 발표장에서 서버·설치 없이 시연 가능.
  드롭아웃은 학습 때만 켜지고 예측 때는 꺼지므로 내보낼 필요 없음.

임계값
  B가 새 모델 기준으로 정한 값을 --threshold 로 넣기. (예전 0.66은 예전 모델 기준이라 쓰면 안 됨)
  안 넣으면 model_card.json의 threshold, 그것도 없으면 0.5 + "미확정" 표시.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

CATEGORICAL = ["Month", "VisitorType"]


def one_hot_like_training(df: pd.DataFrame, columns: list) -> np.ndarray:
    """세션 몇 건만 들어와도 학습 때와 같은 열이 나오도록 변환.
    drop_first=False 원핫 → 학습 열 목록으로 reindex(없는 열 0)."""
    X = df.drop(columns=["Revenue"], errors="ignore").copy()
    X["Weekend"] = X["Weekend"].astype(str).str.lower().map({"true": 1, "false": 0, "1": 1, "0": 0}).astype(float)
    X = pd.get_dummies(X, columns=CATEGORICAL, drop_first=False, dtype=float)
    return X.reindex(columns=columns, fill_value=0.0).astype(float).values


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-dir", default="members/C1/final_model")
    ap.add_argument("--threshold", type=float, default=None, help="B가 정한 임계값")
    ap.add_argument("--check-csv", default=None, help="계산 검증용 원본 형식 CSV (예: data/final/validation_final.csv)")
    ap.add_argument("--out", default="demo_model.json")
    ap.add_argument("--official", action="store_true", default=True)
    ap.add_argument("--stand-in", dest="official", action="store_false", help="임시 모델일 때 표시")
    args = ap.parse_args()

    import joblib
    import tensorflow as tf

    d = Path(args.model_dir)
    model = tf.keras.models.load_model(d / "mlp_final.keras")
    scaler = joblib.load(d / "scaler.joblib")
    cols = json.loads((d / "feature_columns.json").read_text(encoding="utf-8"))
    if isinstance(cols, dict):  # {"columns": [...]} 형식도 허용
        cols = cols.get("columns") or cols.get("feature_columns")
    card = {}
    if (d / "model_card.json").exists():
        card = json.loads((d / "model_card.json").read_text(encoding="utf-8"))

    threshold, th_fixed = args.threshold, True
    if threshold is None:
        threshold = card.get("threshold")
    if threshold is None:
        threshold, th_fixed = 0.5, False

    layers, arch = [], []
    for layer in model.layers:
        if isinstance(layer, tf.keras.layers.Dense):
            W, b = layer.get_weights()
            act = layer.get_config()["activation"]
            layers.append({"W": np.round(W, 8).tolist(), "b": np.round(b, 8).tolist(), "activation": act})
            arch.append(W.shape[1])
    assert len(cols) == layers[0]["W"].__len__(), "열 개수와 첫 층 입력 크기가 다름"

    out = {
        "name": card.get("model_name", "MLP_final_seed42"),
        "arch": "-".join(map(str, arch[:-1])),
        "official": args.official,
        "threshold": threshold,
        "threshold_fixed": th_fixed,
        "columns": cols,
        "categorical": CATEGORICAL,
        "scaler_mean": scaler.mean_.round(10).tolist(),
        "scaler_scale": scaler.scale_.round(10).tolist(),
        "layers": layers,
    }

    # 검증: 원본 형식 몇 행을 Keras로 예측해 같이 저장 → HTML 계산과 비교 가능
    if args.check_csv:
        raw = pd.read_csv(args.check_csv).head(8)
        Xc = scaler.transform(one_hot_like_training(raw, cols))
        out["check"] = {
            "rows": json.loads(raw.drop(columns=["Revenue"], errors="ignore").to_json(orient="records")),
            "keras_prob": model.predict(Xc, verbose=0).ravel().round(6).tolist(),
        }

    Path(args.out).write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    print(f"저장: {args.out}  구조 {out['arch']}, 입력 {len(cols)}차원, 임계값 {threshold}{'' if th_fixed else ' (미확정)'}")


if __name__ == "__main__":
    main()
